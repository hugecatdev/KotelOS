if [ -n "$BASH_VERSION" ] && [ "$BASH" != "/bin/sh" ]; then
. /etc/bash/bashrc
fi
