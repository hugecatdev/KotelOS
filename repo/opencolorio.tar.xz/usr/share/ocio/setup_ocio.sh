#!/bin/sh
export DYLD_LIBRARY_PATH="/usr/lib:${DYLD_LIBRARY_PATH}"
export LD_LIBRARY_PATH="/usr/lib:${LD_LIBRARY_PATH}"
export PATH="/usr/bin:${PATH}"
export PYTHONPATH="/usr/lib/python3.12/site-packages:${PYTHONPATH}"
