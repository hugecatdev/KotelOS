#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "s2::s2" for configuration "MinSizeRel"
set_property(TARGET s2::s2 APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(s2::s2 PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libs2.so.0.11.1"
  IMPORTED_SONAME_MINSIZEREL "libs2.so.0"
  )

list(APPEND _cmake_import_check_targets s2::s2 )
list(APPEND _cmake_import_check_files_for_s2::s2 "${_IMPORT_PREFIX}/lib/libs2.so.0.11.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
