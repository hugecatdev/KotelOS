#!/bin/sh
git checkout gh-pages
git pull
git checkout master
pushd website
./scripts/build-to-gh-pages.sh
git push
git checkout master
popd
