#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "exmdbpp::exmdbpp" for configuration "MinSizeRel"
set_property(TARGET exmdbpp::exmdbpp APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(exmdbpp::exmdbpp PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libexmdbpp.so.0"
  IMPORTED_SONAME_MINSIZEREL "libexmdbpp.so.0"
  )

list(APPEND _cmake_import_check_targets exmdbpp::exmdbpp )
list(APPEND _cmake_import_check_files_for_exmdbpp::exmdbpp "${_IMPORT_PREFIX}/lib/libexmdbpp.so.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
