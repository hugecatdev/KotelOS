export MPLBACKEND=TkAgg
