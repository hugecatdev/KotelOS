export EDITOR=micro
