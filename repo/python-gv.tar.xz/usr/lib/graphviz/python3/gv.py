from sys import version_info as _swig_python_version_info
if __package__ or '.' in __name__:from.import _gv
else:import _gv
try:import builtins as __builtin__
except ImportError:import __builtin__
def _swig_repr(self):
 try:strthis='proxy of '+self.this.__repr__()
 except __builtin__.Exception:strthis=''
 return '<%s.%s; %s >'%(self.__class__.__module__,self.__class__.__name__,strthis)
def _swig_setattr_nondynamic_instance_variable(set):
 def set_instance_attr(self,name,value):
  if name=='this':set(self,name,value)
  elif name=='thisown':self.this.own(value)
  elif hasattr(self,name)and isinstance(getattr(type(self),name),property):set(self,name,value)
  else:raise AttributeError('You cannot add instance attributes to %s'%self)
 return set_instance_attr
def _swig_setattr_nondynamic_class_variable(set):
 def set_class_attr(cls,name,value):
  if hasattr(cls,name)and(not isinstance(getattr(cls,name),property)):set(cls,name,value)
  else:raise AttributeError('You cannot add class attributes to %s'%cls)
 return set_class_attr
def _swig_add_metaclass(metaclass):
 def wrapper(cls):return metaclass(cls.__name__,cls.__bases__,cls.__dict__.copy())
 return wrapper
class _SwigNonDynamicMeta(type):__setattr__=_swig_setattr_nondynamic_class_variable(type.__setattr__)
def digraph(name):return _gv.digraph(name)
def strictgraph(name):return _gv.strictgraph(name)
def strictdigraph(name):return _gv.strictdigraph(name)
def readstring(string):return _gv.readstring(string)
def read(*args):return _gv.read(*args)
def graph(*args):return _gv.graph(*args)
def node(g,name):return _gv.node(g,name)
def edge(*args):return _gv.edge(*args)
def setv(*args):return _gv.setv(*args)
def getv(*args):return _gv.getv(*args)
def nameof(*args):return _gv.nameof(*args)
def findsubg(g,name):return _gv.findsubg(g,name)
def findnode(g,name):return _gv.findnode(g,name)
def findedge(t,h):return _gv.findedge(t,h)
def findattr(*args):return _gv.findattr(*args)
def headof(e):return _gv.headof(e)
def tailof(e):return _gv.tailof(e)
def graphof(*args):return _gv.graphof(*args)
def rootof(g):return _gv.rootof(g)
def protonode(g):return _gv.protonode(g)
def protoedge(g):return _gv.protoedge(g)
def ok(*args):return _gv.ok(*args)
def firstsubg(g):return _gv.firstsubg(g)
def nextsubg(g,sg):return _gv.nextsubg(g,sg)
def firstsupg(g):return _gv.firstsupg(g)
def nextsupg(g,sg):return _gv.nextsupg(g,sg)
def firstedge(*args):return _gv.firstedge(*args)
def nextedge(*args):return _gv.nextedge(*args)
def firstout(*args):return _gv.firstout(*args)
def nextout(*args):return _gv.nextout(*args)
def firsthead(n):return _gv.firsthead(n)
def nexthead(n,h):return _gv.nexthead(n,h)
def firstin(*args):return _gv.firstin(*args)
def nextin(*args):return _gv.nextin(*args)
def firsttail(n):return _gv.firsttail(n)
def nexttail(n,t):return _gv.nexttail(n,t)
def firstnode(*args):return _gv.firstnode(*args)
def nextnode(*args):return _gv.nextnode(*args)
def firstattr(*args):return _gv.firstattr(*args)
def nextattr(*args):return _gv.nextattr(*args)
def rm(*args):return _gv.rm(*args)
def layout(g,engine):return _gv.layout(g,engine)
def render(*args):return _gv.render(*args)
def renderresult(g,format,outdata):return _gv.renderresult(g,format,outdata)
def renderchannel(g,format,channelname):return _gv.renderchannel(g,format,channelname)
def renderdata(g,format):return _gv.renderdata(g,format)
def write(*args):return _gv.write(*args)
def tred(g):return _gv.tred(g)
